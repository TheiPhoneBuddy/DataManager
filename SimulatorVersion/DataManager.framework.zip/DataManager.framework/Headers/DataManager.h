//
//  DataManager.h
//  DataManager
//
//  Created by Francis Chan on 11/14/17.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DataManager.
FOUNDATION_EXPORT double DataManagerVersionNumber;

//! Project version string for DataManager.
FOUNDATION_EXPORT const unsigned char DataManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DataManager/PublicHeader.h>
